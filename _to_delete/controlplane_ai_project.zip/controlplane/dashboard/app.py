"""
HITL Dashboard — live view of everything the Dynamic Action Engine and the
three micro-agents are doing (spec 3.3: "fires a webhook to the HITL
dashboard").

No `websockets`/`wsproto` package is installable in this sandbox, so this
uses Server-Sent Events (sse-starlette, already available) instead of a
WebSocket — one-directional server push is all a live telemetry feed
needs anyway. A background task drains the `actions`, `escalations`, and
`agent-results` Redis streams (via their own dashboard consumer groups —
see event_bus.ensure_groups) and fans each new event out to every
connected browser tab.
"""
from __future__ import annotations

import asyncio
import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from sse_starlette.sse import EventSourceResponse
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse
from starlette.routing import Route

from ..event_bus import new_connected_bus

logger = logging.getLogger("controlplane.dashboard")

STATIC_DIR = Path(__file__).parent / "static"

_subscribers: set[asyncio.Queue] = set()
_recent: list[dict] = []  # small ring buffer so a newly-opened tab isn't blank
_RECENT_MAX = 200
_stats = {
    "total_requests": 0,
    "low": 0,
    "medium": 0,
    "high": 0,
    "session_cost_usd": 0.0,
}


def _broadcast(payload: dict) -> None:
    _recent.append(payload)
    if len(_recent) > _RECENT_MAX:
        _recent.pop(0)
    for q in list(_subscribers):
        q.put_nowait(payload)


def _bump_stats(payload: dict) -> None:
    if payload.get("kind") == "action":
        _stats["total_requests"] += 1
        level = payload.get("risk_level", "LOW_RISK").split("_")[0].lower()
        if level in ("low", "medium", "high"):
            _stats[level] += 1


async def _consume_loop() -> None:
    bus = await new_connected_bus()
    await bus.ensure_groups()
    logger.info("dashboard consumer loop started")
    while True:
        try:
            actions = await bus.consume_actions(f"cp-agents:dashboard-actions", count=20, block_ms=1500)
            for eid, decision in actions:
                payload = {
                    "kind": "action",
                    "trace_id": decision.trace_id,
                    "risk_level": decision.risk_level.value,
                    "action": decision.action.value,
                    "reason": decision.reason,
                    "contributing_agents": decision.contributing_agents,
                    "latency_impact": decision.latency_impact,
                    "created_at": decision.created_at,
                }
                _bump_stats(payload)
                _broadcast(payload)
                await bus.ack_action("cp-agents:dashboard-actions", eid)

            results = await bus.consume_findings("cp-agents:dashboard-results", count=20, block_ms=100)
            for eid, finding in results:
                payload = {
                    "kind": "finding",
                    "trace_id": finding.trace_id,
                    "agent": finding.agent,
                    "risk_level": finding.risk_level.value,
                    "score": finding.score,
                    "reason": finding.reason,
                    "details": finding.details,
                    "created_at": finding.created_at,
                }
                _broadcast(payload)
                await bus.ack_finding("cp-agents:dashboard-results", eid)

            escalations = await bus.consume_escalations("cp-agents:dashboard-escalations", count=20, block_ms=100)
            for eid, esc in escalations:
                payload = {
                    "kind": "escalation",
                    "trace_id": esc.trace_id,
                    "risk_level": esc.risk_level.value,
                    "reason": esc.reason,
                    "snippet": esc.snippet,
                    "prompt": esc.prompt,
                    "created_at": esc.created_at,
                }
                _broadcast(payload)
                await bus.ack_escalation("cp-agents:dashboard-escalations", eid)

            session_cost = await bus.get_session_total_cost()
            _stats["session_cost_usd"] = round(session_cost, 5)
        except Exception:
            logger.exception("dashboard consume loop error; retrying")
            await asyncio.sleep(1.0)


async def index(request: Request):
    return FileResponse(STATIC_DIR / "index.html")


async def summary(request: Request) -> JSONResponse:
    return JSONResponse({"stats": _stats, "recent": _recent[-50:]})


async def events(request: Request) -> EventSourceResponse:
    queue: asyncio.Queue = asyncio.Queue()
    _subscribers.add(queue)

    async def gen():
        try:
            for payload in _recent[-30:]:
                yield {"event": "cp", "data": json.dumps(payload)}
            while True:
                if await request.is_disconnected():
                    break
                try:
                    payload = await asyncio.wait_for(queue.get(), timeout=15.0)
                    yield {"event": "cp", "data": json.dumps(payload)}
                except asyncio.TimeoutError:
                    yield {"event": "ping", "data": json.dumps({"stats": _stats})}
        finally:
            _subscribers.discard(queue)

    return EventSourceResponse(gen())


@asynccontextmanager
async def lifespan(app: Starlette):
    task = asyncio.create_task(_consume_loop())
    try:
        yield
    finally:
        task.cancel()


app = Starlette(
    routes=[
        Route("/", index, methods=["GET"]),
        Route("/api/summary", summary, methods=["GET"]),
        Route("/api/events", events, methods=["GET"]),
    ],
    lifespan=lifespan,
)
