"""
Grounding / hallucination-detection retriever for the Performance Agent
(spec 3.2.3: "optimized RAG pipelines for verification ... quantized
Cross-Encoders to compute real-time semantic similarity scores between the
LLM output and grounded enterprise context vectors").

Honest caveat, documented rather than hidden: a real cross-encoder
(e.g. ms-marco-MiniLM via sentence-transformers) needs downloaded model
weights, and this sandbox has no egress to PyPI or Hugging Face to fetch
either the library or the weights. We substitute TF-IDF cosine similarity
over the enterprise KB — a classical, dependency-free (scikit-learn is
already installed) grounding signal that answers the same question a
cross-encoder would ("how well does this output's vocabulary/content
overlap with what our own documents actually say?"). It is less
semantically nuanced than a neural cross-encoder — it won't catch a
paraphrase that uses completely different words for the same grounded
fact — but it reliably catches the demo-critical failure mode: an answer
that states facts (numbers, policies, guarantees) nowhere in the KB.

`Retriever.grounding_score()` is the seam: swap its body for a real
sentence-transformers CrossEncoder(...).predict(...) call in any
environment with model-download access, and nothing else in the codebase
needs to change.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .documents import DOCUMENTS

_TOKEN_RE = re.compile(r"[a-zA-Z0-9]+")
_NUMERIC_CLAIM_RE = re.compile(
    r"\$\s?[\d,]+(?:\.\d+)?\s?(?:million|billion|k)?"      # dollar amounts
    r"|\d+(?:\.\d+)?\s?%"                                    # percentages
    r"|\b\d+[-\s]?(?:day|days|hour|hours|minute|minutes|year|years|business day|business days)\b",
    re.IGNORECASE,
)


def _content_tokens(text: str) -> set[str]:
    return {t for t in _TOKEN_RE.findall(text.lower()) if t not in ENGLISH_STOP_WORDS and len(t) > 1}


def _normalize_numeric(claim: str) -> str:
    return re.sub(r"\s+", " ", claim.strip().lower())


def extract_numeric_claims(text: str) -> set[str]:
    """Pull out concrete, checkable claims: percentages, dollar figures,
    and time durations. These are exactly the kind of specific facts a
    holistic semantic-similarity score can miss when an LLM stays
    on-topic but invents the number (e.g. correctly discussing the SLA,
    but claiming '100% uptime' instead of the real '99.9%')."""
    return {_normalize_numeric(m) for m in _NUMERIC_CLAIM_RE.findall(text)}


def numeric_consistency(output_claims: set[str], doc_claims: set[str]) -> float:
    """1.0 = every numeric claim in the output also appears in the matched
    doc (or the output made no checkable claims at all). Drops toward 0 as
    more of the output's specific numbers are simply absent from the
    source of truth it's supposedly grounded in."""
    if not output_claims:
        return 1.0
    matched = sum(1 for c in output_claims if c in doc_claims)
    return matched / len(output_claims)


@dataclass
class GroundingMatch:
    doc_id: str
    title: str
    similarity: float


class Retriever:
    """Grounding score = a blend of TF-IDF cosine similarity (rewards
    matching the *specific, weighted* phrasing of a doc) and content-word
    recall against the best-matching doc (rewards paraphrases that reuse
    the same facts in different words, which cosine alone under-scores —
    see module docstring for why we don't have a neural cross-encoder
    here). Blending the two catches more real paraphrase cases than either
    alone while still tanking on genuinely fabricated facts, since a
    fabricated number/claim shares neither the doc's phrasing nor its
    vocabulary.
    """

    def __init__(self, documents: list[dict] = DOCUMENTS):
        self.documents = documents
        self._vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        corpus = [d["text"] for d in documents]
        self._doc_matrix = self._vectorizer.fit_transform(corpus)
        self._doc_tokens = [_content_tokens(d["text"]) for d in documents]
        self._doc_numeric_claims = [extract_numeric_claims(d["text"]) for d in documents]

    def top_matches(self, text: str, k: int = 3) -> list[GroundingMatch]:
        if not text.strip():
            return []
        query_vec = self._vectorizer.transform([text])
        cosine_sims = cosine_similarity(query_vec, self._doc_matrix)[0]
        query_tokens = _content_tokens(text)

        blended = []
        for i, cos_sim in enumerate(cosine_sims):
            if query_tokens:
                overlap = len(query_tokens & self._doc_tokens[i]) / len(query_tokens)
            else:
                overlap = 0.0
            blended.append(0.45 * float(cos_sim) + 0.55 * overlap)

        ranked = sorted(range(len(blended)), key=lambda i: blended[i], reverse=True)[:k]
        return [
            GroundingMatch(doc_id=self.documents[i]["id"], title=self.documents[i]["title"], similarity=blended[i])
            for i in ranked
        ]

    def grounding_score(self, text: str) -> float:
        """Best-match similarity in [0, 1], penalized for any specific
        numeric claim (a %, a dollar figure, an SLA duration, ...) that the
        best-matching doc simply doesn't contain. Low = ungrounded /
        potentially hallucinated relative to the enterprise KB. See
        `numeric_consistency` docstring for why this matters: lexical
        similarity alone tends to miss "right topic, invented number,"
        which is one of the most common and highest-stakes hallucination
        shapes in an enterprise support/policy setting."""
        matches = self.top_matches(text, k=1)
        if not matches:
            return 0.0
        best = matches[0]
        doc_index = next(i for i, d in enumerate(self.documents) if d["id"] == best.doc_id)

        output_claims = extract_numeric_claims(text)
        consistency = numeric_consistency(output_claims, self._doc_numeric_claims[doc_index])

        if output_claims and consistency < 1.0:
            # Scale the lexical similarity down by how numerically
            # inconsistent the response is — a response that gets the
            # topic right but fabricates every number should read as
            # clearly worse than one that gets everything right.
            return best.similarity * (0.15 + 0.35 * consistency)
        return best.similarity


_singleton: Retriever | None = None


def get_retriever() -> Retriever:
    global _singleton
    if _singleton is None:
        _singleton = Retriever()
    return _singleton
