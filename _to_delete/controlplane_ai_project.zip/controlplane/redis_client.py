"""
A minimal, dependency-free async Redis client (RESP2 over asyncio streams).

Why this exists: the target deployment environment for ControlPlane.ai has
no restrictions and should just `pip install redis[hiredis]`. This
sandbox, however, has no outbound access to PyPI or the Ubuntu package
mirrors (verified: both return 403 at the network egress layer), so the
`redis` package cannot be installed here. Rather than fake the Redis layer
with an in-process queue — which would silently misrepresent the
"asynchronous event bus decoupling the proxy from evaluation" requirement
in spec 3.2.2 — this module speaks real RESP2 to a real `redis-server`
process over a real socket. It implements exactly the command surface
ControlPlane.ai needs (streams, consumer groups, simple KV/hash counters).

Swap-in note: anywhere this module is imported, `pip install redis` and
switching to `redis.asyncio.Redis` is a drop-in replacement — the call
signatures here mirror the real client's (`xadd`, `xreadgroup`, `xack`,
`incrbyfloat`, `hincrby`, ...) on purpose.
"""
from __future__ import annotations

import asyncio
from typing import Any, Iterable, Optional


class RedisError(Exception):
    pass


def _encode_command(*args: Any) -> bytes:
    parts = [f"*{len(args)}\r\n".encode()]
    for arg in args:
        if isinstance(arg, bytes):
            b = arg
        else:
            b = str(arg).encode()
        parts.append(f"${len(b)}\r\n".encode() + b + b"\r\n")
    return b"".join(parts)


class RedisClient:
    """One connection, one in-flight command at a time (guarded by a lock).

    That's enough for our workload: each agent/proxy worker owns its own
    RedisClient instance (see event_bus.get_client()), so concurrency comes
    from having multiple connections, exactly as a real pooled client would
    give you.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 6379):
        self.host = host
        self.port = port
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._lock = asyncio.Lock()

    async def connect(self) -> "RedisClient":
        self._reader, self._writer = await asyncio.open_connection(self.host, self.port)
        return self

    async def close(self) -> None:
        if self._writer:
            self._writer.close()
            try:
                await self._writer.wait_closed()
            except Exception:
                pass

    async def _read_reply(self) -> Any:
        assert self._reader is not None
        line = await self._reader.readline()
        if not line:
            raise RedisError("connection closed by server")
        prefix, payload = line[:1], line[1:-2]  # strip \r\n

        if prefix == b"+":
            return payload.decode()
        if prefix == b"-":
            raise RedisError(payload.decode())
        if prefix == b":":
            return int(payload)
        if prefix == b"$":
            n = int(payload)
            if n == -1:
                return None
            data = await self._reader.readexactly(n + 2)
            return data[:-2].decode(errors="replace")
        if prefix == b"*":
            n = int(payload)
            if n == -1:
                return None
            return [await self._read_reply() for _ in range(n)]
        raise RedisError(f"unknown RESP prefix: {prefix!r}")

    async def execute(self, *args: Any) -> Any:
        if self._writer is None:
            await self.connect()
        async with self._lock:
            self._writer.write(_encode_command(*args))
            await self._writer.drain()
            return await self._read_reply()

    # ---- convenience wrappers (mirror redis-py's async API surface) --------

    async def ping(self) -> bool:
        return await self.execute("PING") == "PONG"

    async def set(self, key: str, value: Any) -> None:
        await self.execute("SET", key, value)

    async def get(self, key: str) -> Optional[str]:
        return await self.execute("GET", key)

    async def incrby(self, key: str, amount: int = 1) -> int:
        return await self.execute("INCRBY", key, amount)

    async def incrbyfloat(self, key: str, amount: float) -> float:
        return float(await self.execute("INCRBYFLOAT", key, amount))

    async def hincrby(self, key: str, field: str, amount: int = 1) -> int:
        return await self.execute("HINCRBY", key, field, amount)

    async def hincrbyfloat(self, key: str, field: str, amount: float) -> float:
        return float(await self.execute("HINCRBYFLOAT", key, field, amount))

    async def hgetall(self, key: str) -> dict:
        flat = await self.execute("HGETALL", key) or []
        return dict(zip(flat[0::2], flat[1::2]))

    async def expire(self, key: str, seconds: int) -> None:
        await self.execute("EXPIRE", key, seconds)

    # ---- streams -------------------------------------------------------------

    async def xadd(self, stream: str, fields: dict, maxlen: Optional[int] = 10000) -> str:
        args: list[Any] = ["XADD", stream]
        if maxlen:
            args += ["MAXLEN", "~", maxlen]
        args.append("*")
        for k, v in fields.items():
            args += [k, v]
        return await self.execute(*args)

    async def xgroup_create(self, stream: str, group: str, start_id: str = "0") -> None:
        try:
            await self.execute("XGROUP", "CREATE", stream, group, start_id, "MKSTREAM")
        except RedisError as e:
            if "BUSYGROUP" not in str(e):
                raise

    async def xreadgroup(
        self,
        group: str,
        consumer: str,
        stream: str,
        count: int = 10,
        block_ms: int = 2000,
    ) -> list[tuple[str, dict]]:
        reply = await self.execute(
            "XREADGROUP", "GROUP", group, consumer,
            "COUNT", count, "BLOCK", block_ms,
            "STREAMS", stream, ">",
        )
        return self._parse_stream_reply(reply)

    async def xack(self, stream: str, group: str, *ids: str) -> None:
        await self.execute("XACK", stream, group, *ids)

    async def xrange(self, stream: str, start: str = "-", end: str = "+", count: Optional[int] = None) -> list[tuple[str, dict]]:
        args = ["XRANGE", stream, start, end]
        if count:
            args += ["COUNT", count]
        reply = await self.execute(*args) or []
        return [(entry_id, dict(zip(flat[0::2], flat[1::2]))) for entry_id, flat in reply]

    async def xlen(self, stream: str) -> int:
        return await self.execute("XLEN", stream) or 0

    @staticmethod
    def _parse_stream_reply(reply: Any) -> list[tuple[str, dict]]:
        if not reply:
            return []
        out: list[tuple[str, dict]] = []
        for _stream_name, entries in reply:
            for entry_id, flat in entries:
                out.append((entry_id, dict(zip(flat[0::2], flat[1::2]))))
        return out
