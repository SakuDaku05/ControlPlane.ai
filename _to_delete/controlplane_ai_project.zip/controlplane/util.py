"""Small shared helpers that don't belong to any one component."""
from __future__ import annotations


def estimate_tokens(text: str) -> int:
    """Cheap token-count heuristic (~0.75 words/token for English) used
    whenever a provider hasn't reported real usage numbers yet (e.g. mid-
    stream, or the Mock provider, which has no real tokenizer). Good
    enough for the Cost Telemetry Agent's "streaming token heuristics"
    (spec 3.2.3) — swap for `tiktoken` in a production build with model-
    specific tokenizers."""
    if not text:
        return 0
    words = text.split()
    return max(1, round(len(words) / 0.75))
